let question = [
    { question: "Quelle est la capital de la France", options: [Paris, London, Madrid], answer: 0}, 
    { question: "Quelle est la capital de la Espagne", options: [Paris, London, Madrid], answer: 2}, 
    { question: "Quelle est la capital de la Italie", options: [Paris, Rome, Madrid], answer: 1}, 
    { question: "Quelle est la capital de la Angleterre", options: [London, Washigton, Paris], answer: 0}, 
    { question: "Quelle est la capital de la Mexique", options: [Mexico, London, Madrid], answer: 0}, 
    { question: "Quelle est la capital de la USA", options: [Paris, London, Washigton], answer: 2}     
];

/* module.exports = {
    question:question,
} */